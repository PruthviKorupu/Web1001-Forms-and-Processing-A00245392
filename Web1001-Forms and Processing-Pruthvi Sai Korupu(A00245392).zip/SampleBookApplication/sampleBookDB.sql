create database SampleBookDB

use SampleBookDB

create table dbo.Book
(
Id int,
BookName nvarchar(50),
BookDescription nvarchar(200)
)